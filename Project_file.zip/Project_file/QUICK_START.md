# Quick Start Guide - Dashboard Data Display

## 🚀 Steps to Show Data:

### 1. **Create Users Table in MySQL:**
```sql
USE district_dashboard;
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    taluk VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 2. **Run Data Insertion:**
```bash
python data_insertion_script.py
```
OR
```bash
node data_insertion.js
```

### 3. **Start Server:**
Double-click `run_server.bat` or run:
```bash
node backend/server.js
```

### 4. **Access Dashboard:**
- Open browser: `http://localhost:3000`
- Register new user with any taluk
- Login and view dashboard

## 📊 **Dashboard Features:**

### **Main Dashboard (index.html):**
- All 6 taluks data overview
- Education bar chart by taluk
- Health pie chart distribution
- Real-time statistics

### **Education Page:**
- Schools infrastructure charts
- Facilities distribution
- Taluk-wise comparison

### **Health Page:**
- Maternal care metrics
- Vaccination coverage
- Delivery statistics

## 🎯 **Data Sources:**
- **Education:** Schools, buildings, electricity, computers, libraries
- **Health:** Pregnancies, deliveries, BCG, measles vaccination
- **All data from MySQL database**

## ✅ **Expected Results:**
- Charts showing real data from CSV files
- Interactive taluk selection
- Dynamic data updates
- Responsive visualizations