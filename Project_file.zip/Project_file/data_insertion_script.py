import pandas as pd
import mysql.connector
from mysql.connector import Error

# Database connection configuration
DB_CONFIG = {
    'host': 'localhost',
    'database': 'district_dashboard',
    'user': 'root',
    'password': 'your_password'  # Update with your MySQL password
}

def connect_database():
    """Create database connection"""
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        if connection.is_connected():
            print("Successfully connected to MySQL database")
            return connection
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None

def clear_existing_data(connection):
    """Clear existing data from tables"""
    cursor = connection.cursor()
    try:
        cursor.execute("DELETE FROM education_data")
        cursor.execute("DELETE FROM health_data")
        cursor.execute("DELETE FROM agriculture_data")
        cursor.execute("DELETE FROM food_processing_data")
        connection.commit()
        print("Existing data cleared successfully")
    except Error as e:
        print(f"Error clearing data: {e}")
    finally:
        cursor.close()

def insert_education_data(connection):
    """Insert education data from CSV"""
    try:
        # Read education CSV
        df = pd.read_csv('Bagalkot_Education_Cleaned.csv')
        
        # Group by district and block, sum the metrics
        grouped = df.groupby(['District_Name', 'Udise_Block_Name']).agg({
            'Total_Number_of_Schools': 'sum',
            'Building': 'sum',
            'Functional_Electricity': 'sum',
            'Computer_Available': 'sum',
            'Library_or_Reading_Corner_or_Book_Bank': 'sum',
            'Playground': 'sum'
        }).reset_index()
        
        cursor = connection.cursor()
        
        for _, row in grouped.iterrows():
            query = """
            INSERT INTO education_data 
            (district_name, block_name, total_schools, building, functional_electricity, 
             computer_availability, library_facilities, playground) 
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            values = (
                row['District_Name'],
                row['Udise_Block_Name'],
                int(row['Total_Number_of_Schools']),
                int(row['Building']),
                int(row['Functional_Electricity']),
                int(row['Computer_Available']),
                int(row['Library_or_Reading_Corner_or_Book_Bank']),
                int(row['Playground'])
            )
            cursor.execute(query, values)
        
        connection.commit()
        print(f"Inserted {len(grouped)} education records")
        
    except Exception as e:
        print(f"Error inserting education data: {e}")
    finally:
        cursor.close()

def insert_health_data(connection):
    """Insert health data from CSV"""
    try:
        # Read health CSV
        df = pd.read_csv('Health_sector_cleaned_short.csv')
        
        # Extract relevant columns for each block
        blocks = ['Badami', 'Bagalkot', 'Bilagi', 'Hunagund', 'Jamakhandi', 'Mudhole']
        
        cursor = connection.cursor()
        
        for block in blocks:
            # Get pregnant women registered (row 0)
            pregnant_women = df.iloc[0][f'{block}_Total'] if f'{block}_Total' in df.columns else 0
            
            # Get institutional deliveries (row 26)
            institutional_deliveries = df.iloc[26][f'{block}_Total'] if f'{block}_Total' in df.columns else 0
            
            # Get BCG vaccination (row 82)
            vaccination_bcg = df.iloc[82][f'{block}_Total'] if f'{block}_Total' in df.columns else 0
            
            # Get Measles vaccination (row 122)
            vaccination_measles = df.iloc[122][f'{block}_Total'] if f'{block}_Total' in df.columns else 0
            
            query = """
            INSERT INTO health_data 
            (district_name, block_name, pregnant_women_registered, institutional_deliveries, 
             vaccination_bcg, vaccination_measles) 
            VALUES (%s, %s, %s, %s, %s, %s)
            """
            values = (
                'BAGALKOT',
                block.upper(),
                int(pregnant_women) if pd.notna(pregnant_women) else 0,
                int(institutional_deliveries) if pd.notna(institutional_deliveries) else 0,
                int(vaccination_bcg) if pd.notna(vaccination_bcg) else 0,
                int(vaccination_measles) if pd.notna(vaccination_measles) else 0
            )
            cursor.execute(query, values)
        
        connection.commit()
        print(f"Inserted {len(blocks)} health records")
        
    except Exception as e:
        print(f"Error inserting health data: {e}")
    finally:
        cursor.close()

def insert_agriculture_data(connection):
    """Insert agriculture data (sample data)"""
    try:
        cursor = connection.cursor()
        
        # Sample agriculture data for each block
        agriculture_data = [
            ('BADAMI', 2650.45, 42500.80, 71.2),
            ('BAGALKOT', 2850.75, 45600.50, 72.3),
            ('BILAGI', 2420.60, 38900.25, 69.8),
            ('HUNAGUND', 2780.90, 44200.75, 73.5),
            ('JAMAKHANDI', 3180.60, 52800.25, 81.2),
            ('MUDHOL', 2950.35, 47300.60, 75.4)
        ]
        
        for data in agriculture_data:
            query = """
            INSERT INTO agriculture_data 
            (district_name, crop_yield, irrigation_area, soil_health) 
            VALUES (%s, %s, %s, %s)
            """
            cursor.execute(query, data)
        
        connection.commit()
        print(f"Inserted {len(agriculture_data)} agriculture records")
        
    except Exception as e:
        print(f"Error inserting agriculture data: {e}")
    finally:
        cursor.close()

def insert_food_processing_data(connection):
    """Insert food processing data from taluka CSV"""
    try:
        # Read the taluka data
        with open('bagalkot_district_talukas.csv.csv', 'r') as file:
            lines = file.readlines()
        
        cursor = connection.cursor()
        
        for line in lines:
            # Parse the line to extract data
            line = line.strip().replace("('", "").replace("'),", "").replace("');", "")
            if line:
                parts = line.split("', ")
                if len(parts) >= 4:
                    district_name = parts[0]
                    industries_count = int(parts[1])
                    employment = int(parts[2])
                    export_value = float(parts[3])
                    
                    query = """
                    INSERT INTO food_processing_data 
                    (district_name, industries_count, employment, export_value) 
                    VALUES (%s, %s, %s, %s)
                    """
                    values = (district_name, industries_count, employment, export_value)
                    cursor.execute(query, values)
        
        connection.commit()
        print("Inserted food processing records")
        
    except Exception as e:
        print(f"Error inserting food processing data: {e}")
    finally:
        cursor.close()

def main():
    """Main function to execute all data insertions"""
    print("Starting data insertion process...")
    
    # Connect to database
    connection = connect_database()
    if not connection:
        return
    
    try:
        # Clear existing data
        clear_existing_data(connection)
        
        # Insert data from all CSV files
        insert_education_data(connection)
        insert_health_data(connection)
        insert_agriculture_data(connection)
        insert_food_processing_data(connection)
        
        print("\nData insertion completed successfully!")
        
        # Verify data insertion
        cursor = connection.cursor()
        cursor.execute("SELECT COUNT(*) FROM education_data")
        education_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM health_data")
        health_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM agriculture_data")
        agriculture_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM food_processing_data")
        food_processing_count = cursor.fetchone()[0]
        
        print(f"\nData verification:")
        print(f"Education records: {education_count}")
        print(f"Health records: {health_count}")
        print(f"Agriculture records: {agriculture_count}")
        print(f"Food processing records: {food_processing_count}")
        
    except Exception as e:
        print(f"Error in main process: {e}")
    
    finally:
        if connection.is_connected():
            connection.close()
            print("\nDatabase connection closed.")

if __name__ == "__main__":
    main()