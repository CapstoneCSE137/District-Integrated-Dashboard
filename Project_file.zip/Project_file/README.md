# District Integrated Dashboard

A complete full-stack web application for district-level analysis across Education, Health, Agriculture, and Food Processing sectors.

## Technologies Used

- **Frontend**: HTML, Inline CSS, JavaScript
- **Charts**: Chart.js for interactive visualizations
- **Backend**: Node.js with Express.js
- **Database**: MySQL

## Features

- **Login System**: Secure authentication with styled login page
- **Multi-Sector Dashboard**: Education, Health, Agriculture, Food Processing
- **Interactive Charts**: Bar, pie, and line charts with Chart.js
- **Dynamic Data Loading**: Real-time updates from MySQL database
- **Responsive Design**: Works on desktop and mobile devices
- **Professional UI**: Modern card layout with data.gov.in inspired design

## Setup Instructions

### 1. Prerequisites
- Node.js (v14 or higher)
- MySQL Server
- Web browser

### 2. Database Setup
```sql
-- Import the SQL file into MySQL
mysql -u root -p < database/district_dashboard.sql
```

### 3. Install Dependencies
```bash
npm install
```

### 4. Configure Database
Update `backend/db.js` with your MySQL credentials if needed:
```javascript
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', // Add your MySQL password here
    database: 'district_dashboard'
});
```

### 5. Start the Server
```bash
npm start
```

### 6. Access the Application
1. Open your browser and go to: `http://localhost:3000`
2. You'll be redirected to the login page
3. Login credentials:
   - Username: `admin`
   - Password: `admin123`
4. After login, explore the dashboard and different sectors

## Project Structure

```
District-Dashboard-Complete/
├── frontend/
│   ├── login.html          # Login page with Meri Pehchaan style
│   ├── index.html          # Homepage with data.gov.in eTaal style
│   ├── education.html      # Education sector page
│   ├── health.html         # Health sector page
│   ├── agriculture.html    # Agriculture sector page
│   ├── food.html          # Food processing sector page
│   ├── script.js          # Main JavaScript functionality
│   └── images/            # UI reference images
├── backend/
│   ├── server.js          # Express server with REST APIs
│   └── db.js              # MySQL database connection
├── database/
│   └── district_dashboard.sql  # Database schema and sample data
├── package.json
└── README.md
```

## API Endpoints

- `GET /api/districts` - Get list of all districts
- `GET /api/education/:district` - Get education data for a district
- `GET /api/health/:district` - Get health data for a district
- `GET /api/agriculture/:district` - Get agriculture data for a district
- `GET /api/food/:district` - Get food processing data for a district

## Sample Data

The application includes sample data for 4 districts:
- Bagalkot
- Belgaum
- Dharwad
- Gadag

## Usage

1. **Login**: Use admin/admin123 to access the dashboard
2. **Navigate**: Use the navigation menu to switch between sectors
3. **Select District**: Use the dropdown to change districts and see data update
4. **Interact**: Click on charts and cards for detailed information
5. **Logout**: Use the logout button to end your session

## Development

To run in development mode with auto-restart:
```bash
npm run dev
```

## License

MIT License - Open source project for educational and development purposes.