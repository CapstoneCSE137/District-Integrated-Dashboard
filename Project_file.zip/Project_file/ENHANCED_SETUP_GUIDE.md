# Enhanced District Integrated Dashboard

## Overview
A comprehensive web-based dashboard for Bagalkot district administration featuring interactive charts, real-time data visualization, and multi-sector analytics covering Education, Health, Agriculture, and Food Processing sectors.

## Features

### 🎯 Core Features
- **Interactive Dashboard**: Real-time data visualization with Chart.js
- **Multi-Sector Analytics**: Education, Health, Agriculture, Food Processing
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **User Authentication**: Secure login system with JWT tokens
- **Role-Based Access**: Admin, Officer, and User roles
- **Data Export**: Export charts and data in various formats

### 📊 Chart Types
- **Pie Charts**: Sector-wise distribution
- **Bar Charts**: Comparative analysis across taluks
- **Line Charts**: Trend analysis over time
- **Doughnut Charts**: Percentage breakdowns
- **Radar Charts**: Multi-dimensional comparisons

### 🏛️ Sectors Covered
1. **Education**: Schools, Infrastructure, Teachers, Students, Literacy
2. **Health**: Hospitals, Patients, Vaccinations, Medical Staff, Equipment
3. **Agriculture**: Crop Yield, Irrigation, Soil Health, Farmers
4. **Food Processing**: Industries, Employment, Export Value, Production

## Installation & Setup

### Prerequisites
- Node.js (v14 or higher)
- MySQL Server (v8.0 or higher)
- Web browser (Chrome, Firefox, Safari, Edge)

### Step 1: Database Setup
```sql
-- Run the enhanced database script
mysql -u root -p < database/enhanced_data_insertion.sql
```

### Step 2: Install Dependencies
```bash
npm install
```

### Step 3: Configure Database Connection
Edit `backend/enhanced_server.js` and update database credentials:
```javascript
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'your_mysql_password',
    database: 'district_dashboard'
});
```

### Step 4: Start the Server
```bash
# Development mode with auto-restart
npm run dev

# Production mode
npm start
```

### Step 5: Access the Dashboard
Open your browser and navigate to: `http://localhost:3000`

## Default Login Credentials
- **Username**: `admin`
- **Password**: `admin123`
- **Role**: Administrator

## API Endpoints

### Authentication
- `POST /api/register` - User registration
- `POST /api/login` - User login

### Data Retrieval
- `GET /api/education/:taluk` - Education data by taluk
- `GET /api/health/:taluk` - Health data by taluk
- `GET /api/agriculture/:taluk` - Agriculture data by taluk
- `GET /api/food/:taluk` - Food processing data by taluk
- `GET /api/dashboard/summary` - Overall dashboard summary
- `GET /api/all-taluks/:sector` - All taluks data for comparison

### Data Management (Admin Only)
- `PUT /api/update/:sector/:taluk` - Update sector data

## Database Schema

### Tables
1. **education_data**: School infrastructure and educational metrics
2. **health_data**: Healthcare facilities and medical statistics
3. **agriculture_data**: Agricultural production and farming data
4. **food_processing_data**: Industrial and employment statistics
5. **users**: User authentication and role management

### Sample Data Included
- 6 Taluks: Badami, Bagalkot, Bilagi, Hunagund, Jamakhandi, Mudhol
- Comprehensive metrics for each sector
- Historical trends and comparative data

## Chart Interactions

### Interactive Features
- **Click Navigation**: Click charts to navigate to detailed pages
- **Hover Information**: Detailed tooltips on data points
- **Dynamic Filtering**: Filter by taluk or time period
- **Responsive Updates**: Real-time data refresh
- **Export Options**: Save charts as images or PDF

### Chart Types by Section
- **Main Dashboard**: Overview charts for all sectors
- **Education**: Infrastructure, facilities, literacy rates
- **Health**: Patient distribution, medical facilities
- **Agriculture**: Crop yield, irrigation coverage
- **Food Processing**: Employment, export performance

## File Structure
```
District-Dashboard-Complete/
├── backend/
│   ├── server.js (original)
│   ├── enhanced_server.js (new)
│   └── db.js
├── database/
│   ├── district_dashboard.sql (original)
│   └── enhanced_data_insertion.sql (new)
├── frontend/
│   ├── index.html (enhanced)
│   ├── education.html (enhanced)
│   ├── health.html (enhanced)
│   ├── agriculture.html (enhanced)
│   ├── food.html (enhanced)
│   ├── login.html
│   ├── register.html
│   └── script.js
└── package.json (updated)
```

## Customization

### Adding New Charts
1. Add canvas element to HTML
2. Create chart configuration in JavaScript
3. Connect to API endpoint for data
4. Implement interactive features

### Adding New Metrics
1. Update database schema
2. Modify API endpoints
3. Update frontend charts
4. Test data flow

### Styling Customization
- Modify CSS in HTML files
- Update Chart.js color schemes
- Customize responsive breakpoints

## Performance Optimization

### Database
- Indexed columns for faster queries
- Optimized JOIN operations
- Cached frequently accessed data

### Frontend
- Lazy loading of charts
- Compressed assets
- Efficient DOM updates

### Backend
- Connection pooling
- Query optimization
- Error handling

## Security Features
- Password hashing with bcrypt
- JWT token authentication
- SQL injection prevention
- CORS configuration
- Input validation

## Troubleshooting

### Common Issues
1. **Database Connection Failed**
   - Check MySQL service is running
   - Verify credentials in server.js
   - Ensure database exists

2. **Charts Not Loading**
   - Check browser console for errors
   - Verify API endpoints are responding
   - Ensure Chart.js library is loaded

3. **Login Issues**
   - Verify user exists in database
   - Check password hashing
   - Confirm JWT secret is set

### Debug Mode
Enable debug logging by setting:
```javascript
const DEBUG = true;
```

## Future Enhancements
- Real-time data streaming
- Mobile app integration
- Advanced analytics with ML
- Multi-language support
- Offline capability
- Data visualization exports

## Support
For technical support or feature requests, contact the District Administration IT Team.

## License
MIT License - See LICENSE file for details.