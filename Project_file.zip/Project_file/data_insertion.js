const mysql = require('mysql2/promise');
const fs = require('fs');
const csv = require('csv-parser');

// Database configuration
const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: 'your_password', // Update with your MySQL password
    database: 'district_dashboard'
};

// Function to read CSV file
function readCSV(filePath) {
    return new Promise((resolve, reject) => {
        const results = [];
        fs.createReadStream(filePath)
            .pipe(csv())
            .on('data', (data) => results.push(data))
            .on('end', () => resolve(results))
            .on('error', reject);
    });
}

// Clear existing data
async function clearExistingData(connection) {
    try {
        await connection.execute('DELETE FROM education_data');
        await connection.execute('DELETE FROM health_data');
        await connection.execute('DELETE FROM agriculture_data');
        await connection.execute('DELETE FROM food_processing_data');
        console.log('Existing data cleared successfully');
    } catch (error) {
        console.error('Error clearing data:', error);
    }
}

// Insert education data
async function insertEducationData(connection) {
    try {
        const educationData = await readCSV('Bagalkot_Education_Cleaned.csv');
        
        // Group data by district and block
        const groupedData = {};
        
        educationData.forEach(row => {
            const key = `${row.District_Name}_${row.Udise_Block_Name}`;
            if (!groupedData[key]) {
                groupedData[key] = {
                    district_name: row.District_Name,
                    block_name: row.Udise_Block_Name,
                    total_schools: 0,
                    building: 0,
                    functional_electricity: 0,
                    computer_availability: 0,
                    library_facilities: 0,
                    playground: 0
                };
            }
            
            groupedData[key].total_schools += parseInt(row.Total_Number_of_Schools) || 0;
            groupedData[key].building += parseInt(row.Building) || 0;
            groupedData[key].functional_electricity += parseInt(row.Functional_Electricity) || 0;
            groupedData[key].computer_availability += parseInt(row.Computer_Available) || 0;
            groupedData[key].library_facilities += parseInt(row.Library_or_Reading_Corner_or_Book_Bank) || 0;
            groupedData[key].playground += parseInt(row.Playground) || 0;
        });
        
        // Insert grouped data
        for (const key in groupedData) {
            const data = groupedData[key];
            await connection.execute(
                `INSERT INTO education_data 
                (district_name, block_name, total_schools, building, functional_electricity, 
                 computer_availability, library_facilities, playground) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                [data.district_name, data.block_name, data.total_schools, data.building,
                 data.functional_electricity, data.computer_availability, 
                 data.library_facilities, data.playground]
            );
        }
        
        console.log(`Inserted ${Object.keys(groupedData).length} education records`);
    } catch (error) {
        console.error('Error inserting education data:', error);
    }
}

// Insert health data
async function insertHealthData(connection) {
    try {
        const healthData = await readCSV('Health_sector_cleaned_short.csv');
        
        const blocks = ['Badami', 'Bagalkot', 'Bilagi', 'Hunagund', 'Jamakhandi', 'Mudhole'];
        
        for (const block of blocks) {
            // Extract data for each block from specific rows
            const pregnantWomen = parseInt(healthData[0]?.[`${block}_Total`]) || 0;
            const institutionalDeliveries = parseInt(healthData[26]?.[`${block}_Total`]) || 0;
            const vaccinationBCG = parseInt(healthData[82]?.[`${block}_Total`]) || 0;
            const vaccinationMeasles = parseInt(healthData[122]?.[`${block}_Total`]) || 0;
            
            await connection.execute(
                `INSERT INTO health_data 
                (district_name, block_name, pregnant_women_registered, institutional_deliveries, 
                 vaccination_bcg, vaccination_measles) 
                VALUES (?, ?, ?, ?, ?, ?)`,
                ['BAGALKOT', block.toUpperCase(), pregnantWomen, institutionalDeliveries, 
                 vaccinationBCG, vaccinationMeasles]
            );
        }
        
        console.log(`Inserted ${blocks.length} health records`);
    } catch (error) {
        console.error('Error inserting health data:', error);
    }
}

// Insert agriculture data
async function insertAgricultureData(connection) {
    try {
        const agricultureData = [
            ['BADAMI', 2650.45, 42500.80, 71.2],
            ['BAGALKOT', 2850.75, 45600.50, 72.3],
            ['BILAGI', 2420.60, 38900.25, 69.8],
            ['HUNAGUND', 2780.90, 44200.75, 73.5],
            ['JAMAKHANDI', 3180.60, 52800.25, 81.2],
            ['MUDHOL', 2950.35, 47300.60, 75.4]
        ];
        
        for (const data of agricultureData) {
            await connection.execute(
                `INSERT INTO agriculture_data 
                (district_name, crop_yield, irrigation_area, soil_health) 
                VALUES (?, ?, ?, ?)`,
                data
            );
        }
        
        console.log(`Inserted ${agricultureData.length} agriculture records`);
    } catch (error) {
        console.error('Error inserting agriculture data:', error);
    }
}

// Insert food processing data
async function insertFoodProcessingData(connection) {
    try {
        const fileContent = fs.readFileSync('bagalkot_district_talukas.csv.csv', 'utf8');
        const lines = fileContent.split('\n');
        
        for (const line of lines) {
            if (line.trim()) {
                // Parse the line format: "('DISTRICT', industries, employment, export_value),"
                const cleanLine = line.replace(/['"(),;]/g, '').trim();
                const parts = cleanLine.split(', ');
                
                if (parts.length >= 4) {
                    const districtName = parts[0];
                    const industriesCount = parseInt(parts[1]);
                    const employment = parseInt(parts[2]);
                    const exportValue = parseFloat(parts[3]);
                    
                    await connection.execute(
                        `INSERT INTO food_processing_data 
                        (district_name, industries_count, employment, export_value) 
                        VALUES (?, ?, ?, ?)`,
                        [districtName, industriesCount, employment, exportValue]
                    );
                }
            }
        }
        
        console.log('Inserted food processing records');
    } catch (error) {
        console.error('Error inserting food processing data:', error);
    }
}

// Main function
async function main() {
    let connection;
    
    try {
        console.log('Starting data insertion process...');
        
        // Create database connection
        connection = await mysql.createConnection(dbConfig);
        console.log('Connected to MySQL database');
        
        // Clear existing data
        await clearExistingData(connection);
        
        // Insert data from all CSV files
        await insertEducationData(connection);
        await insertHealthData(connection);
        await insertAgricultureData(connection);
        await insertFoodProcessingData(connection);
        
        console.log('\nData insertion completed successfully!');
        
        // Verify data insertion
        const [educationRows] = await connection.execute('SELECT COUNT(*) as count FROM education_data');
        const [healthRows] = await connection.execute('SELECT COUNT(*) as count FROM health_data');
        const [agricultureRows] = await connection.execute('SELECT COUNT(*) as count FROM agriculture_data');
        const [foodProcessingRows] = await connection.execute('SELECT COUNT(*) as count FROM food_processing_data');
        
        console.log('\nData verification:');
        console.log(`Education records: ${educationRows[0].count}`);
        console.log(`Health records: ${healthRows[0].count}`);
        console.log(`Agriculture records: ${agricultureRows[0].count}`);
        console.log(`Food processing records: ${foodProcessingRows[0].count}`);
        
    } catch (error) {
        console.error('Error in main process:', error);
    } finally {
        if (connection) {
            await connection.end();
            console.log('\nDatabase connection closed.');
        }
    }
}

// Run the script
main();