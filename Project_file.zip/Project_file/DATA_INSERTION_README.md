# District Dashboard - CSV Data Integration Guide

This guide explains how to connect and insert data from all 4 CSV files into your MySQL database.

## CSV Files Overview

1. **Bagalkot_Education_Cleaned.csv** - Education infrastructure data
2. **Health_sector_cleaned_short.csv** - Healthcare delivery metrics  
3. **bagalkot_district_talukas.csv.csv** - Food processing industry data
4. **cas.csv.xlsx** - Additional data (Excel format)

## Database Tables

- `education_data` - School infrastructure metrics
- `health_data` - Healthcare delivery data
- `agriculture_data` - Farming and crop data
- `food_processing_data` - Industrial metrics

## Setup Instructions

### Option 1: Python Script (Recommended)

1. **Install Python Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Update Database Configuration:**
   Edit `data_insertion_script.py` and update the MySQL password:
   ```python
   DB_CONFIG = {
       'host': 'localhost',
       'database': 'district_dashboard',
       'user': 'root',
       'password': 'your_actual_password'  # Update this
   }
   ```

3. **Run the Script:**
   ```bash
   python data_insertion_script.py
   ```

### Option 2: Node.js Script

1. **Install Node.js Dependencies:**
   ```bash
   npm install
   ```

2. **Update Database Configuration:**
   Edit `data_insertion.js` and update the MySQL password:
   ```javascript
   const dbConfig = {
       host: 'localhost',
       user: 'root',
       password: 'your_actual_password', // Update this
       database: 'district_dashboard'
   };
   ```

3. **Run the Script:**
   ```bash
   node data_insertion.js
   ```

## Data Mapping

### Education Data
- **Source:** Bagalkot_Education_Cleaned.csv
- **Processing:** Groups by District_Name and Udise_Block_Name, sums metrics
- **Fields:** Total schools, buildings, electricity, computers, libraries, playgrounds

### Health Data  
- **Source:** Health_sector_cleaned_short.csv
- **Processing:** Extracts specific rows for each block
- **Fields:** Pregnant women registered, institutional deliveries, BCG vaccination, measles vaccination

### Agriculture Data
- **Source:** Sample data (can be updated with actual CSV)
- **Fields:** Crop yield, irrigation area, soil health by district

### Food Processing Data
- **Source:** bagalkot_district_talukas.csv.csv
- **Processing:** Parses formatted data lines
- **Fields:** Industries count, employment, export value by district

## Verification

After running either script, you'll see output like:
```
Data verification:
Education records: 6
Health records: 6  
Agriculture records: 6
Food processing records: 6
```

## Database Schema

The scripts work with the existing database schema defined in `database/district_dashboard.sql`.

## Troubleshooting

1. **MySQL Connection Error:**
   - Ensure MySQL server is running
   - Verify username/password
   - Check if database exists

2. **CSV File Not Found:**
   - Ensure CSV files are in the same directory as the script
   - Check file names match exactly

3. **Data Type Errors:**
   - Scripts handle missing/invalid data with default values
   - Check CSV format if errors persist

## Manual Data Insertion

If scripts fail, you can manually insert data using the existing INSERT statements in `district_dashboard.sql`.

## Next Steps

1. Run the data insertion script
2. Start the backend server: `npm start`
3. Open `frontend/index.html` in browser
4. Verify data displays correctly in dashboard

## File Structure
```
District-Dashboard-Complete/
├── Bagalkot_Education_Cleaned.csv
├── Health_sector_cleaned_short.csv  
├── bagalkot_district_talukas.csv.csv
├── cas.csv.xlsx
├── data_insertion_script.py
├── data_insertion.js
├── requirements.txt
├── package.json
├── database/district_dashboard.sql
├── backend/server.js
└── frontend/
```